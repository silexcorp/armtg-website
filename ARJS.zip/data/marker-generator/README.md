Make QR: http://flash.tarotaro.org/blog/2009/07/12/mgo2/

by https://twitter.com/tarotarorg

Use on firefox, as chrome seems to be flacky
